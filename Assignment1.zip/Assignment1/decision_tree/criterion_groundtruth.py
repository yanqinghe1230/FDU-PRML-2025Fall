"""
criterion
"""

import math


def get_criterion_function(criterion):
    if criterion == "info_gain":
        return __info_gain
    elif criterion == "info_gain_ratio":
        return __info_gain_ratio
    elif criterion == "gini":
        return __gini_index
    elif criterion == "error_rate":
        return __error_rate


def __label_stat(y, l_y, r_y):
    """Count the number of labels of nodes"""
    left_labels = {}
    right_labels = {}
    all_labels = {}
    for t in y.reshape(-1):
        if t not in all_labels:
            all_labels[t] = 0
        all_labels[t] += 1
    for t in l_y.reshape(-1):
        if t not in left_labels:
            left_labels[t] = 0
        left_labels[t] += 1
    for t in r_y.reshape(-1):
        if t not in right_labels:
            right_labels[t] = 0
        right_labels[t] += 1

    return all_labels, left_labels, right_labels


def __info_gain(y, l_y, r_y):
    """
    Calculate the info gain

    y, l_y, r_y: label array of father node, left child node, right child node
    """
    all_labels, left_labels, right_labels = __label_stat(y, l_y, r_y)

    ###########################################################################
    # Calculate the information gain = H(parent) - [ (n_l/n)*H(left) +        #
    # (n_r/n)*H(right) ]. Handle empty splits by returning 0.                 #
    ###########################################################################
    # *****START OF YOUR CODE (DO NOT DELETE/MODIFY THIS LINE)*****
    n = y.size
    n_l = l_y.size
    n_r = r_y.size

    # invalid/empty split -> no gain
    if n == 0 or n_l == 0 or n_r == 0:
        return 0.0

    def entropy_from_counts(counts, total):
        if total == 0:
            return 0.0
        h = 0.0
        for c in counts.values():
            if c <= 0:
                continue
            p = c / total
            # use log2; skip p<=0 for numerical stability
            h -= p * math.log(p, 2)
        return h

    H_parent = entropy_from_counts(all_labels, n)
    H_left = entropy_from_counts(left_labels, n_l)
    H_right = entropy_from_counts(right_labels, n_r)

    info_gain = H_parent - (n_l / n) * H_left - (n_r / n) * H_right
    # *****END OF YOUR CODE (DO NOT DELETE/MODIFY THIS LINE)*****

    return info_gain


def __info_gain_ratio(y, l_y, r_y):
    """
    Calculate the info gain ratio

    y, l_y, r_y: label array of father node, left child node, right child node
    """
    info_gain = __info_gain(y, l_y, r_y)
    ###########################################################################
    # Information gain ratio = info_gain / split_info, where                  #
    # split_info = - [ (n_l/n) log2(n_l/n) + (n_r/n) log2(n_r/n) ].            #
    # If split_info == 0 (e.g., degenerate split), return 0.                  #
    ###########################################################################
    # *****START OF YOUR CODE (DO NOT DELETE/MODIFY THIS LINE)*****
    n = y.size
    n_l = l_y.size
    n_r = r_y.size

    if n == 0 or n_l == 0 or n_r == 0:
        return 0.0

    # compute split info
    p_l = n_l / n
    p_r = n_r / n
    split_info = 0.0
    if p_l > 0:
        split_info -= p_l * math.log(p_l, 2)
    if p_r > 0:
        split_info -= p_r * math.log(p_r, 2)

    if split_info == 0.0:
        return 0.0

    info_gain_ratio = info_gain / split_info
    # *****END OF YOUR CODE (DO NOT DELETE/MODIFY THIS LINE)*****
    return info_gain_ratio


def __gini_index(y, l_y, r_y):
    """
    Calculate the gini index

    y, l_y, r_y: label array of father node, left child node, right child node
    """
    all_labels, left_labels, right_labels = __label_stat(y, l_y, r_y)

    ###########################################################################
    # Compute Gini decrease: G(parent) - [ (n_l/n)*G(left) + (n_r/n)*G(right) ]
    # If a child is empty, return 0.                                          #
    ###########################################################################
    # *****START OF YOUR CODE (DO NOT DELETE/MODIFY THIS LINE)*****
    n = y.size
    n_l = l_y.size
    n_r = r_y.size

    if n == 0 or n_l == 0 or n_r == 0:
        return 0.0

    def gini_from_counts(counts, total):
        if total == 0:
            return 0.0
        sum_sq = 0.0
        for c in counts.values():
            if c <= 0:
                continue
            p = c / total
            sum_sq += p * p
        return 1.0 - sum_sq

    g_parent = gini_from_counts(all_labels, n)
    g_left = gini_from_counts(left_labels, n_l)
    g_right = gini_from_counts(right_labels, n_r)

    before = g_parent
    after = (n_l / n) * g_left + (n_r / n) * g_right
    # *****END OF YOUR CODE (DO NOT DELETE/MODIFY THIS LINE)*****
    return before - after


def __error_rate(y, l_y, r_y):
    """Calculate the error rate"""
    all_labels, left_labels, right_labels = __label_stat(y, l_y, r_y)

    ###########################################################################
    # Error rate decrease: Err(parent) - [ (n_l/n)*Err(left) +                #
    # (n_r/n)*Err(right) ], where Err(node) = 1 - max_class_prob.             #
    # If a child is empty, return 0.                                          #
    ###########################################################################
    # *****START OF YOUR CODE (DO NOT DELETE/MODIFY THIS LINE)*****
    n = y.size
    n_l = l_y.size
    n_r = r_y.size

    if n == 0 or n_l == 0 or n_r == 0:
        return 0.0

    def err_from_counts(counts, total):
        if total == 0:
            return 0.0
        max_count = 0
        for c in counts.values():
            if c > max_count:
                max_count = c
        return 1.0 - (max_count / total)

    e_parent = err_from_counts(all_labels, n)
    e_left = err_from_counts(left_labels, n_l)
    e_right = err_from_counts(right_labels, n_r)

    before = e_parent
    after = (n_l / n) * e_left + (n_r / n) * e_right
    # *****END OF YOUR CODE (DO NOT DELETE/MODIFY THIS LINE)*****
    return before - after
